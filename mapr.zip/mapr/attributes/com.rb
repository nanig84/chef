default['com']['dev']['mapr'] =  %w(mapr-client.x86_64 mapr-hbase.noarch)
default['com']['stg']['mapr'] =  %w(mapr-spark.noarch)
default['com']['Prodzone']['mapr'] = %w(mapr-spark.noarch)
