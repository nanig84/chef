# Sample for location details

# information  about  UNH-DEV
default['unh']['dev']['microsfotr'] = 'microsoftr-x.x.x.tar.gz'
default['unh']['dev']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'
default['unh']['dev']['mapr'] = %w(mapr-client.x86_64 mapr-hbase.noarch
                                   mapr-hive.noarch mapr-hivemetastore.noarch
                                   mapr-hiveserver2.noarch mapr-spark.noarch)
default['unh']['dev']['anaconda'] = 'Anaconda3-4.3.1-Linux-x86_64.sh'
default['unh']['dev']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'

# default setting for UNHG-TEST
default['unh']['test']['mapr'] = %w(mapr-client.x86_64 mapr-hbase.noarch
                                    mapr-hive.noarch mapr-hivemetastore.noarch
                                    mapr-hiveserver2.noarch mapr-spark.noarch)
default['unh']['test']['anaconda'] = 'Anaconda3-4.3.1-Linux-x86_64.sh'
default['unh']['dev']['zeppelin'] = 'zeppelin-0.7.2-bin-all.tgz'
