# host adding new ###
default['apsrs6775']['zone'] = 'unh'
default['apsrs6775']['env'] = 'dev'

default['apsrs6756']['zone'] = 'unh'
default['apsrs6756']['env'] = 'test'

default['repo_server'] = 'http://apsrs6756.uhc.com/'
# default['nodejs_url'] = 'https://rpm.nodesource.com/setup_6.x '

default['pkg_name'] = %w( pcre pcre-devel xz xz-devel bzip2-devel libicu-devel
                          gcc-gfortran.x86_64
                          zlib.x86_64
                          unixODBC-devel
                          unixODBC
                          libtool
                          readline-devel
                          python-devel.x86_64
                          libxml2-devel
                          openssl-devel.x86_64
                          libcurl-devel
                          gcc-c++
                          make
                          gcc
                          firefox
                          git
                          zlib.x86_64
                          zlib-devel.x86_64 nfs-utils
                          java-1.8.0-openjdk-devel)
