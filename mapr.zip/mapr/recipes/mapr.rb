#
# Cookbook Name:: optum_mapr/
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
hname = node['hostname']
hzone = node[hname.to_s]['zone']
henv  = node[hname.to_s]['env']
hpkgmapr = node[hzone.to_s][henv.to_s]['mapr']

cookbook_file '/etc/profile.d/hadoop.env' do
  source 'hadoop.env'
  owner 'root'
  group 'root'
  mode '0644'
  action :create
end

node[hzone.to_s][henv.to_s]['mapr'].each do |p|
  yum_package p do
    # yum_package "#{hpkgmapr}"
    # yum_package ['mapr-client.x86_64', 'mapr-hbase.noarch', 'mapr-hive.noarch', 'mapr-hivemetastore.noarch', 'mapr-hiveserver2.noarch', 'mapr-spark.noarch'] do
    ignore_failure true
  end
end

link '/opt/mapr/hbase/hbase' do
  to '/opt/mapr/hbase/hbase-1.1.8'
end

link '/opt/mapr/hadoop/hadoop' do
  to '/opt/mapr/hadoop/hadoop-2.7.0'
end

link '/opt/mapr/hive/hive' do
  to '/opt/mapr/hive/hive-2.1'
end

link '/opt/mapr/spark/spark' do
  to '/opt/mapr/spark/spark-2.1.0'
end
