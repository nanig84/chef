yum_package 'rstudio.x86_64' do
  # ignore_failure true
end

# 'move rstudio to /app/R'
execute 'mv /usr/lib/rstudio /app/R/' do
  not_if { File.exist?('/app/R/rstudio') }
end

link '/usr/bin/rstudio' do
  to '/app/R/rstudio'
end

yum_package 'rstudio-server.x86_64' do
  # ignore_failure true
end

# 'move rstudio-server to /app/R' do
execute 'mv /usr/lib/rstudio-server /app/R/' do
  not_if { File.exist?('/app/R/rstudio-server') }
end

link '/usr/bin/rstudio-server' do
  to '/app/R/rstudio-server'
end

bash 'Copy login pam.d to rstudio' do
  user 'root'
  code <<-EOH
    cp /etc/pam.d/login /etc/pam.d/rstudio
  EOH
end

# add the below line /etc/rstudio/rserver.conf
# rsession-ld-library-path=/app/drivers/nz/lib64:/usr/lib/oracle/12.2/client64/lib:/opt/mapr/java/jdk1.8.0_101
bash 'adding rsession-id to rserver.conf' do
  user 'root'
  code <<-EOH
    grep "rsession-ld-library-path=/app/drivers/nz/lib64:/usr/lib/oracle/12.2/client64/lib:/opt/mapr/java/jdk1.8.0_101"  /etc/rstudio/rserver.conf | grep -v grep
    if [ $? -ne 0 ]
    then
        echo "rsession-ld-library-path=/app/drivers/nz/lib64:/usr/lib/oracle/12.2/client64/lib:/opt/mapr/java/jdk1.8.0_101" >> /etc/rstudio/rserver.conf
    fi
  EOH
end
