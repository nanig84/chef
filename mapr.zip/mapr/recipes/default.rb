#
# Cookbook Name:: optum_mapr/
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
# installing default required pacakge
# #Section for get the values from attribute files
hname = node['hostname']
hzone = node[hname.to_s]['zone']
henv  = node[hname.to_s]['env']
node.hpkgmapr = node[hzone.to_s][henv.to_s]['mapr']
node.normal['pkg_anaconda'] = node[hzone.to_s][henv.to_s]['anaconda']
node.normal['pkg_zeppelin'] = node[hzone.to_s][henv.to_s]['zeppelin']
node.normal['pkg_weka'] = node[hzone.to_s][henv.to_s]['weka']
node.normal['pkg_openrefine'] = node[hzone.to_s][henv.to_s]['openrefine']

node['pkg_name'].each do |pkg|
  yum_package pkg.to_s do
    flush_cache [:before]
  end
end

directory '/app' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

yum_repository 'optum_dsi' do
  description 'DSI Repo'
  baseurl 'http://apsrs6756.uhc.com/'
  gpgcheck false
  action :create
end

include_recipe 'optum_mapr::mapr'
include_recipe 'optum_mapr::r'
include_recipe 'optum_mapr::rstudio'
include_recipe 'optum_mapr::anaconda'
include_recipe 'optum_mapr::drivers'
include_recipe 'optum_mapr::zeppelin'
include_recipe 'optum_mapr::weka'
include_recipe 'optum_mapr::h2o'
include_recipe 'optum_mapr::openrefine'
