# mkdir /app/zeppelin
directory '/app/zeppelin' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/packages/zeppelin-0.7.2-bin-all.tgz' do
  source 'http://apsrs6756.uhc.com/softwares/zeppelin-0.7.2-bin-all.tgz'
  action :create
end

bash 'extract_module' do
  cwd '/packages'
  code <<-EOH
    tar -xzvf /packages/zeppelin-0.7.2-bin-all.tgz -C /app/zeppelin
    mv /app/zeppelin/zeppelin-0.7.2-bin-all /app/zeppelin/zeppelin-0.7.2
    EOH
  not_if { ::File.exist?('/app/zeppelin/zeppelin-0.7.2') }
end
# execute "tar -xzvf /packages/zeppelin-0.7.2-bin-all.tgz  -C /app/zeppelin" do
#   cwd '/app/zeppelin/'
#   not_if { File.exist?("/app/zeppelin/zeppelin-0.7.2") }
# end
#
# execute "mv /app/zeppelin/zeppelin-0.7.2-bin-all /app/zeppelin/zeppelin-0.7.2" do
#   cwd '/app/zeppelin/'
#   not_if { File.exist?("/app/zeppelin/zeppelin-0.7.2") }
#  end

%w(shiro.ini zeppelin-site.xml).each do |z1|
  cookbook_file "/app/zeppelin/zeppelin-0.7.2/conf#{z1}" do
    source z1.to_s
    action :create
  end
end

cookbook_file '/etc/systemd/system/zeppelin.service' do
  source 'zeppelin.service'
  action :create
end

service 'zeppelin' do
  action [:enable, :start]
end
