directory '/app/openrefine' do
  action :create
end

remote_file '/packages/openrefine-linux-2.7.tar.gz' do
  source 'http://apsrs6756.uhc.com/softwares/openrefine-linux-2.7.tar.gz'
  action :create
end
# remote_file "/packages/#{node['pkg_openrefine']}" do
#   source "#{node['repo_server']}/softwares/#{node['pkg_openrefine']}"
#   action :create
# end

execute 'tar -xzf /packages/openrefine-linux-2.7.tar.gz -C /app/openrefine' do
  not_if { File.exist?('/app/openrefine/openrefine-2.7') }
end

cookbook_file '/app/openrefine/openrefine-2.7/openrefine_start.sh' do
  source 'openrefine_start.sh'
  action :create
end

cookbook_file '/etc/systemd/system/openrefine.service' do
  source 'openrefine.service'
  action :create
end

service 'openrefine' do
  action [:enable, :start]
end
