directory '/app/weka' do
  action :create
end

remote_file '/packages/weka-3-8-1.zip' do
  source 'http://apsrs6756.uhc.com/softwares/weka-3-8-1.zip'
  action :create
end

execute 'unzip /packages/weka-3-8-1.zip -d /app/weka/' do
  not_if { File.exist?('/app/weka/weka-3-8-1') }
end

# remote_file "/packages/#{node['pkg_weka']}" do
#   source "#{node['repo_server']}/softwares/#{node['pkg_weka']}"
#   action :create
# end
#
# execute "unzip /packages/#{node['pkg_weka']} -d /app/weka/" do
#   not_if { File.exist?("/app/weka/weka-3-8-1") }
# end
