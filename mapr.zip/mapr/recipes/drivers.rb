remote_file '/app/nz.tar' do
  source 'http://apsrs6756.uhc.com/softwares/nz/nz.tar'
  # source "#{node['repo_server']}/softwares/nz/nz.tar"
  action :create
end

bash 'extract_module' do
  cwd '/app'
  code <<-EOH
    mkdir -p  /app/drivers/nz
    tar xf /app/nz.tar -C /app/drivers/nz
    EOH
  not_if { ::File.exist?('/app/drivers/nz.tar') }
end

link '/nz' do
  to '/app/drivers/nz'
end

%w( oracle-instantclient12.2-basic oracle-instantclient12.2-devel
    oracle-instantclient12.2-odbc ).each do |oradriver|
  yum_package oradriver.to_s do
  end
end

remote_file '/usr/lib/oracle/12.2/client64/lib/ojdbc7.jar' do
  source "#{node['repo_server']}/softwares/ojdbc7.jar"
  action :create
end

directory '/etc/skel' do
  action :create
end

cookbook_file '/etc/skel/.bshrc' do
  source 'skel.bashrc'
  action :create
end

cookbook_file '/etc/skel/.bash_profile' do
  source 'skel.bash_profile'
  action :create
end

cookbook_file '/etc/skel/.kshrc' do
  source 'skel.kshrc'
  action :create
end

cookbook_file '/etc/skel/.zshrc' do
  source 'skel.zshrc'
  action :create
end
