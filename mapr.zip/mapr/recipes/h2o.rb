# Installing h20
directory '/app/h2o' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/packages/h2o-3.10.5.4.zip' do
  source 'http://apsrs6756.uhc.com/softwares/h2o-3.10.5.4.zip'
  action :create
end

execute 'unzip /packages/h2o-3.10.5.4.zip -d /app/h2o/' do
  not_if { File.exist?('/app/h2o/h2o-3.10.5.4') }
end
# make sure h20 packages insync, python vs server

# Installing Sparking Water
directory '/app/sparkling-water' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

remote_file '/packages/sparkling-water-2.1.13.zip' do
  source 'http://apsrs6756.uhc.com/softwares/sparkling-water-2.1.13.zip'
  action :create
end

execute 'unzip /packages/sparkling-water-2.1.13.zip -d /app/sparkling-water/' do
  not_if { File.exist?('/app/sparkling-water/sparkling-water-2.1.13') }
end
