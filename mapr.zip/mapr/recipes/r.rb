# creating a directory to store tar files
directory '/packages' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

# copying microsoftr tar file /packages
remote_file '/packages/microsoft-r-open-3.3.3.tar.gz' do
  source 'http://apsrs6756.uhc.com/softwares/microsoft-r-open-3.3.3.tar.gz'
  action :create
end

# bash 'extract_microsoftr_tar' do
#   cwd '/packages'
#   code <<-EOH
#   tar -xzvf /packages/microsoft-r-open-3.3.3.tar.gz
#   EOH
# end
execute 'tar -xzvf /packages/microsoft-r-open-3.3.3.tar.gz' do
  cwd '/packages'
  not_if { File.exist?('/packages/microsoft-r-open') }
end

bash 'install_microsoftr' do
  user 'root'
  cwd '/packages/microsoft-r-open/'
  code <<-EOH
  ./install.sh -u -a -s
  EOH
end

directory '/app/R' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

# 'move microsoftr to /app/R' do
execute 'mv /usr/lib64/microsoft-r /app/R/' do
  not_if { File.exist?('/app/R/microsoft-r') }
end

link '/usr/lib64/microsoft-r' do
  to '/app/R/microsoft-r'
end

link '/usr/bin/R_3.3.3' do
  to '/usr/lib64/microsoft-r/3.3/lib64/R/bin/R'
end

# run this command as root
bash 'R CMD javaconf' do
  user 'root'
  code <<-EOH
     R CMD javareconf
  EOH
end
