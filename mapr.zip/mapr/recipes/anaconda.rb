# remote_file "/app/#{node['pkg_anaconda']}" do
#   source "#{node['repo_server']}/softwares/#{node['pkg_anaconda']}"
#   action :create
# end
remote_file "/app/#{node.normal['pkg_anaconda']}" do
  source "#{node.default['repo_server']}/softwares/#{node.normal['pkg_anaconda']}"
  action :create
end

bash "#{node['pkg_anaconda']} installation" do
  user 'root'
  cwd '/app'
  code <<-EOH
   /bin/sh #{node['pkg_anaconda']} -b -f -p /app/anaconda3
  EOH
  not_if { File.exist?('/app/anaconda3') }
end

execute 'curl --silent --location https://rpm.nodesource.com/setup_6.x | bash -' do
  not_if { File.exist?('/etc/yum.repos.d/nodesource-el.repo') }
end

yum_package 'nodejs' do
  ignore_failure true
end

execute 'npm install -g configurable-http-proxy' do
end

bash node['pkg_anaconda'].to_s do
  user 'root'
  cwd '/app/anaconda3'
  code <<-EOH
  /app/anaconda3/bin/conda install -c conda-forge jupyterhub=0.7.2
  /app/anaconda3/bin/conda install notebook
  /app/anaconda3/bin/conda create -n python352 python=3.5.2 ipykernel
  source /app/anaconda3/bin/activate python352
  /app/anaconda3/envs/python352/bin/python -m ipykernel install --name python352 --display-name "Python (3.5.2)"
  source /app/anaconda3/bin/deactivate python352
  /app/anaconda3/bin/conda create -n python275 python=2.7.5 ipykernel
  source /app/anaconda3/bin/activate python275
  /app/anaconda3/envs/python275/bin/python -m ipykernel install --name python275 --display-name "Python (2.7.5)"
  source /app/anaconda3/bin/deactivate python275
  EOH
end

# mkdir /app/anaconda3/srv
directory '/app/anaconda3/srv' do
  owner 'root'
  group 'root'
  mode '0755'
  action :create
end

%w(jupyterhub.key jupyterhub.crt).each do |f1|
  cookbook_file "/app/anaconda3/srv/#{f1}" do
    source f1.to_s
    action :create
  end
end

%w(jupyterhub_config.py cull_idle_servers.py startjupyterhub.sh).each do |f1|
  cookbook_file "/app/anaconda3/srv/#{f1}" do
    source f1.to_s
    action :create
  end
end

cookbook_file '/etc/systemd/system/jupyterhub.service' do
  source 'jupyterhub.service'
  action :create
end

# bash 'Copy login pam.d to rstudio' do
#   user 'root'
#   code <<-EOH
#   cp jupyterhub.key /app/anaconda3/srv
#   cp jupyterhub.crt /app/anaconda3/srv
#   cp jupyterhub.config /app/anaconda3/bin
#   cp cull_idle_servers.py /app/anaconda3/bin
#   cp startjupyterhub.sh /app/anaconda3/bin
#   cp juypterhub.service /etc/systemd/system
#   EOH
# end

service 'jupyterhub' do
  action [:enable, :start]
end
