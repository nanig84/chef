#!/bin/bash
PATH=${PATH}:/app/anaconda3/bin
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/app/drivers/nz/lib64:/usr/local/unixODBC/lib

jupyterhub -f /app/anaconda3/bin/jupyterhub_config.py 2>&1
root@apsrp03589:/app/anaconda3/bin
#!/bin/bash
PATH=${PATH}:/app/anaconda3/bin
LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/app/drivers/nz/lib64:/usr/local/unixODBC/lib

jupyterhub -f /app/anaconda3/bin/jupyterhub_config.py 2>&1
