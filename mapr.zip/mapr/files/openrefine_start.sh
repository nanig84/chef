#!/bin/sh
host=`hostname`
/app/openrefine/openrefine-2.7/refine -i $host >> openrefine.log &
